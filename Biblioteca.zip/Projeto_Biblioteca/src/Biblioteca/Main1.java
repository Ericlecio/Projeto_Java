package Biblioteca;

import java.util.Date;
import java.util.List;

public class Main1 {
    public static void main(String[] args) {
        // Exemplo de uso das classes do sistema de biblioteca

        // Cria um catálogo e adiciona alguns livros
        Catalogo catalogo = new Catalogo();
        Livro livro1 = new Livro("Livro 1", "Autor 1", 2000, 5);
        Livro livro2 = new Livro("Livro 2", "Autor 2", 2005, 3);
        catalogo.adicionarLivro(livro1);
        catalogo.adicionarLivro(livro2);

        // Cria um aluno e um professor
        Aluno aluno = new Aluno("Aluno 1", 20, "Endereço 1", 12345);
        Professor professor = new Professor("Professor 1", 35, "Endereço 2", 54321);

        // Realiza empréstimos
        try {
            aluno.emprestarLivro(livro1);
            professor.emprestarLivro(livro2);
        } catch (BibliotecaException e) {
            System.out.println("Erro ao emprestar livro: " + e.getMessage());
        }

        // Exibe o status dos livros
        System.out.println("Livro 1 disponível? " + livro1.estaDisponivel());
        System.out.println("Livro 2 disponível? " + livro2.estaDisponivel());

        // Cria um bibliotecário
        Bibliotecario bibliotecario = new Bibliotecario("Bibliotecário 1", 30, "M123");
        bibliotecario.adicionarLivro(new Livro("Livro 3", "Autor 3", 2010, 2), catalogo);

        // Pesquisa livros por autor
        List<Livro> livrosDoAutor2 = catalogo.pesquisarLivros("Autor 2");
        for (Livro livro : livrosDoAutor2) {
            System.out.println("Livro do Autor 2: " + livro.getTitulo());
        }

        // Cria uma estante
        Estante estante = new Estante();
        estante.adicionarLivro(livro1);
        estante.adicionarLivro(livro2);
        List<Livro> livrosNaEstante = estante.getLivros();
        System.out.println("Livros na estante:");
        for (Livro livro : livrosNaEstante) {
            System.out.println(livro.getTitulo());
        }
    }
}

