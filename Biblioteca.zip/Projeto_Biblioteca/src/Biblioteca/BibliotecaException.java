package Biblioteca;

public class BibliotecaException extends Exception {
	public BibliotecaException(String message) {
        super(message);
    }
}
