package Biblioteca;

import java.util.ArrayList;
import java.util.List;

public class Editora {
	private String nome;
	private String endereco;
	private List<Livro> livrosPublicados;

	public Editora(String nome, String endereco) {
		this.nome = nome;
		this.endereco = endereco;
		this.livrosPublicados = new ArrayList<>();
	}

	public void adicionarLivro(Livro livro) {
		livrosPublicados.add(livro);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public List<Livro> getLivrosPublicados() {
		return livrosPublicados;
	}

	public void setLivrosPublicados(List<Livro> livrosPublicados) {
		this.livrosPublicados = livrosPublicados;
	}
	
	
}
