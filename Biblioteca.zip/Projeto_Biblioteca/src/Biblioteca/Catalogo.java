package Biblioteca;

import java.util.ArrayList;
import java.util.List;

public class Catalogo {
	private List<Livro> livros;
	private List<Periodico> periodicos;

	public Catalogo() {
		livros = new ArrayList<>();
		periodicos = new ArrayList<>();
	}

	public void adicionarLivro(Livro livro) {
		livros.add(livro);
	}

	public void removerLivro(Livro livro) {
		livros.remove(livro);
	}

	public List<Livro> pesquisarLivros(String termo) {
		List<Livro> resultados = new ArrayList<>();
		for (Livro livro : livros) {
			if (livro.getTitulo().contains(termo) || livro.getAutor().contains(termo)) {
				resultados.add(livro);
			}
		}
		return resultados;
	}

	public void adicionarPeriodico(Periodico periodico) {
		periodicos.add(periodico);
	}

	public void removerPeriodico(Periodico periodico) {
		periodicos.remove(periodico);
	}

	public List<Periodico> pesquisarPeriodicos(String termo) {
		List<Periodico> resultados = new ArrayList<>();
		for (Periodico p : periodicos) {
			if (p.getTitulo().contains(termo)) {
				resultados.add(p);
			}
		}
		return resultados;
	}


}
