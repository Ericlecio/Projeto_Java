package Biblioteca;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BibliotecaMain {
	public static void main(String[] args) throws BibliotecaException {
		// Criação do livros
		Livro livro1 = new Livro("Livro 1", "Autor 1", 2000);
		Livro livro2 = new Livro("Livro 2", "Autor 2", 2005);
		Livro livro3 = new Livro("Livro 3", "Autor 3", 2010);

		//Criação das Pessoas, Professor/Aluno
		Professor professor = new Professor("Prof. João", 40, "Rua A", 1234);
		Aluno aluno = new Aluno("Aluno Maria", 20, "Rua B", 5678);

		
		// Adicionando os livros a estante de livros.
		Estante estante = new Estante();
		estante.adicionarLivro(livro1);
		estante.adicionarLivro(livro2);
		estante.adicionarLivro(livro3);

		
		// Criando ItemEmprestimo1 e adicionando o  livro com a data de devolução prevista
		ItemEmprestimo itemEmprestimo1 = new ItemEmprestimo(livro1, new Date());
		// Criando Emprestimo e adicionando itemEmprestimo1
		Emprestimo emprestimo1 = new Emprestimo(professor);
		emprestimo1.adicionarItem(itemEmprestimo1);
		
		// Criando ItemEmprestimo2 e adicionando o  livro com a data de devolução prevista
		ItemEmprestimo itemEmprestimo2 = new ItemEmprestimo(livro2, new Date());
		// Criando Emprestimo e adicionando itemEmprestimo2
		Emprestimo emprestimo2 = new Emprestimo(aluno);
		emprestimo2.adicionarItem(itemEmprestimo2);
		
		
		// Criando ItemReservas 1 e adicionando livro 
		ItemReserva itemReserva1 = new ItemReserva(livro2);
		// Criando Reserva1 e adicionando ItemReserva 1
		Reserva reserva1 = new Reserva(professor);
		reserva1.adicionarItem(itemReserva1);

		// Criando ItemReservas2 e adicionando livro 
		ItemReserva itemReserva2 = new ItemReserva(livro3);
		// Criando Reserva2 e adicionando ItemReserva2
		Reserva reserva2 = new Reserva(aluno);
		reserva2.adicionarItem(itemReserva2);

		
		
		
		// Crie uma multa
		Multa multa = new Multa(professor, 10.0);

		// Coloque os objetos em listas para facilitar a iteração
		
		List<Livro> livros = estante.getLivros();
		List<Emprestimo> emprestimos = new ArrayList<>();
		
		emprestimos.add(emprestimo1);
		emprestimos.add(emprestimo2);
		
		
		List<Reserva> reservas = new ArrayList<>();
		reservas.add(reserva1);
		reservas.add(reserva2);
		List<Multa> multas = new ArrayList<>();
		multas.add(multa);

		// Imprima os objetos
		System.out.println("Livros na estante:");
		for (Livro livro : livros) {
			System.out.println(livro.getTitulo());
		}

		System.out.println("\nEmpréstimos:");
		for (Emprestimo emprestimo : emprestimos) {
			System.out.println("Pessoa: " + emprestimo.getPessoa().getNome());
			System.out.println("Itens de Empréstimo:");
			for (ItemEmprestimo item : emprestimo.getItens()) {
				System.out.println("Livro: " + item.getLivro().getTitulo());
			}
		}

		System.out.println("\nReservas:");
		for (Reserva reserva : reservas) {
			System.out.println("Pessoa: " + reserva.getPessoa().getNome());
			System.out.println("Itens de Reserva:");
			for (ItemReserva item : reserva.getItens()) {
				System.out.println("Livro: " + item.getLivro().getTitulo());
			}
		}

		System.out.println("\nMultas:");
		for (Multa multaItem : multas) {
			System.out.println("Pessoa: " + multaItem.getPessoa().getNome());
			System.out.println("Valor da Multa: " + multaItem.getValor());
		}
	}
}
