package Biblioteca;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Emprestimo {
	private Pessoa pessoa;
	private Date dataEmprestimo;
	private Date dataDevolucao;
	private List<ItemEmprestimo> itens;

	public Emprestimo(Pessoa pessoa) {
		this.pessoa = pessoa;
		this.dataEmprestimo = new Date();
		this.itens = new ArrayList<>();
	}

	public void adicionarItem(ItemEmprestimo item) {
		itens.add(item);
	}

	public void registrarDevolucao() {
		dataDevolucao = new Date();
	}
}
