package Biblioteca;

import java.util.Date;

public class Periodico {
	private String titulo;
	private int edicao;
	private Date dataPublicacao;
	private boolean disponivel;
	private int numeroExemplares;

	public Periodico(String titulo, int edicao, Date dataPublicacao, int numeroExemplares) {
		this.titulo = titulo;
		this.edicao = edicao;
		this.dataPublicacao = dataPublicacao;
		this.disponivel = true;
		this.numeroExemplares = numeroExemplares;
	}
	
	

	public boolean estaDisponivel() {
		return disponivel;
	}

	public void emprestar() {
		if (numeroExemplares > 0) {
			disponivel = false;
			numeroExemplares--;
		}
	}

	public void devolver() {
		disponivel = true;
		numeroExemplares++;
	}



	public String getTitulo() {
		return titulo;
	}



	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}



	public int getEdicao() {
		return edicao;
	}



	public void setEdicao(int edicao) {
		this.edicao = edicao;
	}



	public Date getDataPublicacao() {
		return dataPublicacao;
	}



	public void setDataPublicacao(Date dataPublicacao) {
		this.dataPublicacao = dataPublicacao;
	}



	public boolean isDisponivel() {
		return disponivel;
	}



	public void setDisponivel(boolean disponivel) {
		this.disponivel = disponivel;
	}



	public int getNumeroExemplares() {
		return numeroExemplares;
	}



	public void setNumeroExemplares(int numeroExemplares) {
		this.numeroExemplares = numeroExemplares;
	}
	
	
}
